import 'package:flutter/material.dart';

// ignore: non_constant_identifier_names
void main() {
  runApp(MyApp());
}

// ignore: must_be_immutable
class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  List<Map<String, dynamic>> atik = [
    {
      "id": 1,
      "tit": "Aprann pwograme ak Python",
      "kontni": "Mwen se Python",
      "koule": const Color(0xffb74093),
    },
    {
      "id": 2,
      "tit": "Aprann pwograme ak JavaScript",
      "kontni": "Mwen se JavaScript",
      "koule": const Color(0xffb74093),
    },
    {
      "id": 3,
      "tit": "Aprann kreye pwòp aplikasyon w",
      "kontni": "Mwen se pwogramè",
      "koule": const Color(0xffb74093),
    },
  ];

  void efase() {
    // i got error with this code
    atik.removeWhere((element) => element["id"] == 1);
    print(atik);

    atik.add(
      {
        "id": 3,
        "tit": "Aprann kreye pwòp aplikasyon w",
        "kontni": "Mwen se pwogramè",
        "koule": const Color(0xffb74093),
      },
    );
    print(atik);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Quiz App',
        home: Scaffold(
            appBar: AppBar(title: const Text('First Quiz')),
            body: Column(
                children: atik
                    .map((e) => Column(children: [
                          Text(e["tit"],
                              style: const TextStyle(
                                  fontSize: 19, color: Color(0xffb74093))),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(e["kontni"],
                              style: const TextStyle(fontSize: 12, color: Color(0xffb74093))),
                          const SizedBox(
                            height: 10,
                          ),
                          ElevatedButton(
                              onPressed: efase, child: const Text("efase"),
                          ),
                          
                          const SizedBox(
                            height: 10,
                          ),
                        ]))
                    .toList())));
  }
}
